export interface Dish {
  id: string;
  name: string;
  description: string;
  tag: string;
  tagColor: "red" | "yellow";
  size: "large" | "medium" | "small";
  hasHazardRibbon: boolean;
  isWildcard?: boolean;
}

export const dishes: Dish[] = [
  {
    id: "black-market-double",
    name: "THE BLACK MARKET DOUBLE",
    description: "Stacked Angus, smoked low, sold faster than it's made.",
    tag: "DROPPED THIS WEEK — LIMITED BATCH",
    tagColor: "red",
    size: "large",
    hasHazardRibbon: false,
  },
  {
    id: "trackers",
    name: "TRACKERS",
    description: "Wings run three ways: Honey Lemon Pepper, Hot Honey, Cajun. Pick a side or don't.",
    tag: "WEEKLY ROTATION — CATCH IT NOW",
    tagColor: "red",
    size: "medium",
    hasHazardRibbon: true,
  },
  {
    id: "counterfeit-spud",
    name: "THE COUNTERFEIT SPUD",
    description: "Loaded baked potato hijacked by fried fish and shrimp. Not on the menu next week.",
    tag: "ONE WEEK ONLY — GONE BY SUNDAY",
    tagColor: "yellow",
    size: "medium",
    hasHazardRibbon: false,
  },
  {
    id: "wildcard",
    name: "THIS WEEK'S WILDCARD",
    description: "We don't announce it. You find out when you call.",
    tag: "CALL TO FIND OUT",
    tagColor: "yellow",
    size: "small",
    hasHazardRibbon: false,
    isWildcard: true,
  },
];
