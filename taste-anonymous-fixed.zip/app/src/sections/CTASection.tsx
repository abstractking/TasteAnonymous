import { motion } from "framer-motion";
import EmberBackground from "@/components/shared/EmberBackground";
import Button from "@/components/shared/Button";

export default function CTASection() {
  return (
    <section
      id="contact"
      style={{
        position: "relative",
        minHeight: "60vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "var(--space-3xl) 0",
        overflow: "hidden",
        background: "var(--color-bg)",
      }}
    >
      {/* Ember Particles (half density) */}
      <EmberBackground density="half" />

      {/* Content */}
      <div
        style={{
          position: "relative",
          zIndex: 1,
          maxWidth: "700px",
          padding: "0 var(--space-md)",
          textAlign: "center",
        }}
      >
        <motion.h2
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}
          style={{
            fontFamily: "var(--font-display)",
            fontSize: "clamp(2rem, 6vw, 4.2rem)",
            color: "var(--color-text)",
            textTransform: "uppercase",
            lineHeight: 1.1,
            marginBottom: "var(--space-md)",
          }}
        >
          THE VAULT DOESN'T WAIT.
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6, delay: 0.15, ease: [0.4, 0, 0.2, 1] }}
          style={{
            fontFamily: "var(--font-body)",
            fontSize: "var(--text-lg)",
            color: "var(--color-text-muted)",
            maxWidth: "500px",
            margin: "0 auto var(--space-xl)",
            lineHeight: 1.5,
          }}
        >
          This week's menu disappears at close. Next week's hasn't been decided yet.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6, delay: 0.3, ease: [0.4, 0, 0.2, 1] }}
          style={{ marginBottom: "var(--space-md)" }}
        >
          <Button href="tel:+13376349915" size="large">
            CALL OR TEXT — (337) 634-9915
          </Button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6, delay: 0.45, ease: [0.4, 0, 0.2, 1] }}
        >
          <a
            href="#hero"
            onClick={(e) => {
              e.preventDefault();
              window.scrollTo({ top: 0, behavior: "smooth" });
            }}
            style={{
              fontFamily: "var(--font-stamp)",
              fontSize: "var(--text-sm)",
              color: "var(--color-yellow)",
              textDecoration: "none",
              transition: "color 200ms ease",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.textDecoration = "underline";
              e.currentTarget.style.color = "var(--color-text)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.textDecoration = "none";
              e.currentTarget.style.color = "var(--color-yellow)";
            }}
          >
            Get early access before it's public → JOIN THE LIST
          </a>
        </motion.div>
      </div>
    </section>
  );
}
