import { useEffect, useRef } from "react";

interface Ember {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  opacity: number;
  fadeSpeed: number;
  color: string;
  swayPhase: number;
  swaySpeed: number;
}

interface EmberBackgroundProps {
  density?: "full" | "half";
  className?: string;
}

export default function EmberBackground({ density = "full", className = "" }: EmberBackgroundProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const embersRef = useRef<Ember[]>([]);
  const animationRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReducedMotion) return;

    const baseCount = density === "half" ? 20 : 40;
    const colors = ["rgba(232, 19, 46, 0.55)", "rgba(244, 213, 0, 0.45)"];

    function resize() {
      if (!canvas) return;
      canvas.width = canvas.offsetWidth * window.devicePixelRatio;
      canvas.height = canvas.offsetHeight * window.devicePixelRatio;
      ctx!.scale(window.devicePixelRatio, window.devicePixelRatio);
    }

    function spawnEmber(): Ember {
      const w = canvas?.offsetWidth || 800;
      const h = canvas?.offsetHeight || 600;
      return {
        x: Math.random() * w,
        y: h + Math.random() * 50,
        vx: 0,
        vy: -(0.3 + Math.random() * 0.5),
        radius: 1.5 + Math.random() * 2.5,
        opacity: 0.3 + Math.random() * 0.4,
        fadeSpeed: 0.001 + Math.random() * 0.002,
        color: colors[Math.floor(Math.random() * colors.length)],
        swayPhase: Math.random() * Math.PI * 2,
        swaySpeed: 0.005 + Math.random() * 0.01,
      };
    }

    resize();
    window.addEventListener("resize", resize);

    // Initialize embers
    embersRef.current = Array.from({ length: baseCount }, spawnEmber);

    function animate() {
      if (!canvas || !ctx) return;
      const w = canvas.offsetWidth;
      const h = canvas.offsetHeight;

      ctx.clearRect(0, 0, w, h);

      for (const ember of embersRef.current) {
        ember.y += ember.vy;
        ember.swayPhase += ember.swaySpeed;
        ember.x += Math.sin(ember.swayPhase) * 0.3;
        ember.opacity -= ember.fadeSpeed;

        // Fade near top
        const topZone = h * 0.2;
        if (ember.y < topZone) {
          ember.opacity *= 0.97;
        }

        // Respawn if faded or off screen
        if (ember.opacity <= 0 || ember.y < -20) {
          const newEmber = spawnEmber();
          Object.assign(ember, newEmber);
        }

        // Draw ember
        ctx.beginPath();
        ctx.arc(ember.x, ember.y, ember.radius, 0, Math.PI * 2);
        ctx.fillStyle = ember.color.replace(/[\d.]+\)$/, `${ember.opacity})`);
        ctx.fill();

        // Glow
        ctx.beginPath();
        ctx.arc(ember.x, ember.y, ember.radius * 3, 0, Math.PI * 2);
        ctx.fillStyle = ember.color.replace(/[\d.]+\)$/, `${ember.opacity * 0.15})`);
        ctx.fill();
      }

      animationRef.current = requestAnimationFrame(animate);
    }

    animate();

    return () => {
      window.removeEventListener("resize", resize);
      cancelAnimationFrame(animationRef.current);
    };
  }, [density]);

  return (
    <canvas
      ref={canvasRef}
      className={`ember-canvas absolute inset-0 w-full h-full pointer-events-none ${className}`}
      style={{ zIndex: 0 }}
    />
  );
}
