import { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { InstagramEmbed } from "react-social-media-embed";
import ScrollReveal from "@/components/shared/ScrollReveal";
import LazyEmbed from "@/components/shared/LazyEmbed";
import Button from "@/components/shared/Button";
import { instagramPosts } from "@/data/instagramPosts";

const GAP_PX = 26; // matches var(--space-md) — kept in sync manually since this needs a number, not a CSS var

export default function Lineup() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [containerWidth, setContainerWidth] = useState(0);
  const [viewportWidth, setViewportWidth] = useState(
    typeof window !== "undefined" ? window.innerWidth : 0
  );
  const carouselRef = useRef<HTMLDivElement>(null);

  // Previously cardsPerView was computed once from window.innerWidth at first render and
  // never updated — resizing/rotating the device wouldn't reflow the carousel. This now
  // re-measures on resize, and also captures the carousel's real pixel width so the slide
  // transform can use exact pixels instead of percentages (see note below).
  useEffect(() => {
    const updateSizes = () => {
      setViewportWidth(window.innerWidth);
      if (carouselRef.current) setContainerWidth(carouselRef.current.offsetWidth);
    };
    updateSizes();
    window.addEventListener("resize", updateSizes);
    return () => window.removeEventListener("resize", updateSizes);
  }, []);

  const cardsPerView = viewportWidth >= 1024 ? 3 : viewportWidth >= 768 ? 2 : 1;

  // Previously each card's width was set as a CSS percentage while sitting in a flex
  // container with a `gap`, then the slide animation moved by `currentSlide * (100/cardsPerView)%`.
  // Percentage transforms resolve against the *track's own* width, and percentage widths on
  // flex children with no explicit container width resolve inconsistently — together these
  // produced the drifting card-bleed seen in the recording (worse at higher slide indices).
  // Measuring the real container width and computing exact pixel widths/offsets avoids both problems.
  const cardWidth =
    containerWidth > 0 ? (containerWidth - (cardsPerView - 1) * GAP_PX) / cardsPerView : 0;

  const maxSlide = Math.max(0, instagramPosts.length - cardsPerView);

  const goNext = () => setCurrentSlide((prev) => Math.min(prev + 1, maxSlide));
  const goPrev = () => setCurrentSlide((prev) => Math.max(prev - 1, 0));

  return (
    <section
      id="the-lineup"
      style={{
        padding: "var(--space-3xl) 0",
        position: "relative",
        zIndex: 2,
        background: "var(--color-bg)",
      }}
    >
      <div
        style={{
          maxWidth: "1200px",
          margin: "0 auto",
          padding: "0 var(--space-md)",
        }}
      >
        {/* Section Label */}
        <ScrollReveal>
          <p
            style={{
              fontFamily: "var(--font-stamp)",
              fontSize: "var(--text-xs)",
              color: "var(--color-yellow)",
              letterSpacing: "0.25em",
              textTransform: "uppercase",
              marginBottom: "var(--space-sm)",
            }}
          >
            THE LINEUP
          </p>
        </ScrollReveal>

        {/* Section Headline */}
        <ScrollReveal delay={0.1}>
          <h2
            style={{
              fontFamily: "var(--font-display)",
              fontSize: "var(--text-2xl)",
              color: "var(--color-text)",
              textTransform: "uppercase",
              lineHeight: 1.1,
              marginBottom: "var(--space-md)",
            }}
          >
            PROOF IT EXISTED.
          </h2>
        </ScrollReveal>

        {/* Section Body */}
        <ScrollReveal delay={0.15}>
          <p
            style={{
              fontFamily: "var(--font-body)",
              fontSize: "var(--text-base)",
              color: "var(--color-text-muted)",
              maxWidth: "600px",
              lineHeight: 1.5,
              marginBottom: "var(--space-xl)",
            }}
          >
            Everything you're about to scroll past already sold out. Follow @tasteanonymous on Instagram for weekly drop notifications — we don't repost it twice.
          </p>
        </ScrollReveal>

        {/* Instagram Follow CTA Banner */}
        <ScrollReveal delay={0.2}>
          <div
            style={{
              background: "var(--color-bg-2)",
              border: "1px solid var(--color-yellow)",
              borderRadius: "var(--radius)",
              padding: "var(--space-lg)",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: "var(--space-md)",
              marginBottom: "var(--space-xl)",
            }}
            className="md:!flex-row"
          >
            {/* Instagram Icon */}
            <svg
              width="32"
              height="32"
              viewBox="0 0 24 24"
              fill="none"
              stroke="var(--color-yellow)"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              style={{ flexShrink: 0 }}
            >
              <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
              <circle cx="12" cy="12" r="5" />
              <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
            </svg>

            {/* Text Stack */}
            <div style={{ flex: 1, textAlign: "center" }} className="md:!text-left">
              <p
                style={{
                  fontFamily: "var(--font-display)",
                  fontSize: "var(--text-base)",
                  color: "var(--color-text)",
                  textTransform: "uppercase",
                  marginBottom: "var(--space-xs)",
                  lineHeight: 1.3,
                }}
              >
                WEEKLY MENU DROPS ON INSTAGRAM STORIES
              </p>
              <p
                style={{
                  fontFamily: "var(--font-body)",
                  fontSize: "var(--text-sm)",
                  color: "var(--color-text-muted)",
                  lineHeight: 1.4,
                }}
              >
                Follow @tasteanonymous to catch the next drop before it sells out.
              </p>
            </div>

            {/* Follow Button */}
            <Button
              href="https://www.instagram.com/tasteanonymous"
              className="whitespace-nowrap"
            >
              FOLLOW @TASTEANONYMOUS
            </Button>
          </div>
        </ScrollReveal>

        {/* Carousel Navigation */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            marginBottom: "var(--space-md)",
          }}
        >
          {/* Prev Arrow */}
          <button
            onClick={goPrev}
            disabled={currentSlide === 0}
            style={{
              width: "48px",
              height: "48px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              background: "transparent",
              border: `1px solid ${currentSlide === 0 ? "var(--color-border)" : "var(--color-red)"}`,
              color: currentSlide === 0 ? "var(--color-border)" : "var(--color-red)",
              cursor: currentSlide === 0 ? "default" : "pointer",
              fontFamily: "var(--font-display)",
              fontSize: "var(--text-xl)",
              transition: "all 150ms ease",
              opacity: currentSlide === 0 ? 0.4 : 1,
            }}
            onMouseEnter={(e) => {
              if (currentSlide > 0) {
                e.currentTarget.style.boxShadow = "var(--shadow-yellow-md)";
                e.currentTarget.style.borderColor = "var(--color-yellow)";
                e.currentTarget.style.color = "var(--color-yellow)";
                e.currentTarget.style.animation = "neonFlicker 150ms ease";
              }
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.boxShadow = "none";
              e.currentTarget.style.borderColor = "var(--color-red)";
              e.currentTarget.style.color = "var(--color-red)";
              e.currentTarget.style.animation = "none";
            }}
          >
            &larr;
          </button>

          {/* Slide Counter */}
          <span
            style={{
              fontFamily: "var(--font-stamp)",
              fontSize: "var(--text-xs)",
              color: "var(--color-text-muted)",
              letterSpacing: "0.15em",
            }}
          >
            {currentSlide + 1} / {instagramPosts.length}
          </span>

          {/* Next Arrow */}
          <button
            onClick={goNext}
            disabled={currentSlide >= maxSlide}
            style={{
              width: "48px",
              height: "48px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              background: "transparent",
              border: `1px solid ${currentSlide >= maxSlide ? "var(--color-border)" : "var(--color-red)"}`,
              color: currentSlide >= maxSlide ? "var(--color-border)" : "var(--color-red)",
              cursor: currentSlide >= maxSlide ? "default" : "pointer",
              fontFamily: "var(--font-display)",
              fontSize: "var(--text-xl)",
              transition: "all 150ms ease",
              opacity: currentSlide >= maxSlide ? 0.4 : 1,
            }}
            onMouseEnter={(e) => {
              if (currentSlide < maxSlide) {
                e.currentTarget.style.boxShadow = "var(--shadow-yellow-md)";
                e.currentTarget.style.borderColor = "var(--color-yellow)";
                e.currentTarget.style.color = "var(--color-yellow)";
                e.currentTarget.style.animation = "neonFlicker 150ms ease";
              }
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.boxShadow = "none";
              e.currentTarget.style.borderColor = "var(--color-red)";
              e.currentTarget.style.color = "var(--color-red)";
              e.currentTarget.style.animation = "none";
            }}
          >
            &rarr;
          </button>
        </div>

        {/* Carousel */}
        <ScrollReveal direction="right" delay={0.25}>
          <div
            ref={carouselRef}
            style={{
              overflow: "hidden",
              position: "relative",
            }}
          >
            <motion.div
              animate={{ x: -(currentSlide * (cardWidth + GAP_PX)) }}
              transition={{ duration: 0.5, ease: [0.4, 0, 0.2, 1] }}
              style={{
                display: "flex",
                gap: `${GAP_PX}px`,
              }}
            >
              {instagramPosts.map((post, index) => (
                <div
                  key={index}
                  style={{
                    width: cardWidth > 0 ? `${cardWidth}px` : `${100 / cardsPerView}%`,
                    flexShrink: 0,
                  }}
                >
                  <motion.div
                    whileHover={{ rotate: -1, scale: 1.02 }}
                    transition={{ duration: 0.2, ease: [0.4, 0, 0.2, 1] }}
                    style={{
                      position: "relative",
                      background: "var(--color-bg-2)",
                      border: "1px solid var(--color-yellow)",
                      borderRadius: "var(--radius)",
                      overflow: "hidden",
                    }}
                  >
                    {/* Hazard-tape corner ribbon — only on flagged cards, not every one */}
                    {post.ribbon && (
                      <div
                        style={{
                          position: "absolute",
                          top: "14px",
                          right: "-32px",
                          width: "140px",
                          transform: "rotate(45deg)",
                          background:
                            "repeating-linear-gradient(45deg, var(--color-yellow) 0 10px, var(--color-bg) 10px 20px)",
                          color: "var(--color-bg)",
                          fontFamily: "var(--font-stamp)",
                          fontSize: "0.55rem",
                          letterSpacing: "0.1em",
                          textAlign: "center",
                          padding: "2px 0",
                          zIndex: 3,
                          pointerEvents: "none",
                        }}
                      />
                    )}

                    {/* Retired stamp overlay */}
                    {post.retired && (
                      <div
                        style={{
                          position: "absolute",
                          top: "16px",
                          left: "16px",
                          border: "2px solid var(--color-red)",
                          color: "var(--color-red)",
                          fontFamily: "var(--font-stamp)",
                          fontSize: "var(--text-sm)",
                          letterSpacing: "0.15em",
                          padding: "4px 10px",
                          transform: "rotate(-8deg)",
                          background: "rgba(10,10,10,0.55)",
                          zIndex: 3,
                          pointerEvents: "none",
                        }}
                      >
                        RETIRED
                      </div>
                    )}

                    <LazyEmbed>
                      <InstagramEmbed
                        url={post.url}
                        width="100%"
                        style={{ maxHeight: "500px", overflow: "hidden" }}
                      />
                    </LazyEmbed>
                  </motion.div>
                  {/* Evidence-tag caption below embed */}
                  <div style={{ padding: "var(--space-sm) 0" }}>
                    <p
                      style={{
                        fontFamily: "var(--font-stamp)",
                        fontSize: "var(--text-xs)",
                        color: "var(--color-text-muted)",
                        marginBottom: "4px",
                      }}
                    >
                      {post.dish}
                    </p>
                    <p
                      style={{
                        fontFamily: "var(--font-stamp)",
                        fontSize: "var(--text-xs)",
                        color: "var(--color-red)",
                        letterSpacing: "0.1em",
                      }}
                    >
                      {post.caption}
                    </p>
                  </div>
                </div>
              ))}
            </motion.div>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
