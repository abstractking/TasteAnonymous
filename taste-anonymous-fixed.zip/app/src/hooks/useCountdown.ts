import { useState, useEffect, useCallback } from "react";

export interface CountdownResult {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  isExpired: boolean;
  wasJustExpired: boolean;
}

function getNextSundayMidnight(): Date {
  const now = new Date();
  const result = new Date(now);
  result.setDate(now.getDate() + ((7 - now.getDay()) % 7));
  result.setHours(23, 59, 59, 0);
  if (result <= now) {
    result.setDate(result.getDate() + 7);
  }
  return result;
}

export function useCountdown(): CountdownResult {
  const [targetDate, setTargetDate] = useState<Date>(getNextSundayMidnight);
  const [now, setNow] = useState<Date>(new Date());
  const [wasJustExpired, setWasJustExpired] = useState(false);

  const resetTarget = useCallback(() => {
    setTargetDate(getNextSundayMidnight());
    setWasJustExpired(false);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      const current = new Date();
      setNow(current);

      if (current >= targetDate) {
        setWasJustExpired(true);
        setTimeout(resetTarget, 2000);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [targetDate, resetTarget]);

  const diffMs = Math.max(0, targetDate.getTime() - now.getTime());
  const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((diffMs % (1000 * 60)) / 1000);

  return {
    days,
    hours,
    minutes,
    seconds,
    isExpired: diffMs === 0,
    wasJustExpired,
  };
}
