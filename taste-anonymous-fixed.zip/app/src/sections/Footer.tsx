export default function Footer() {
  return (
    <footer
      style={{
        padding: "var(--space-xl) 0 var(--space-lg)",
        borderTop: "1px solid var(--color-border)",
        position: "relative",
        zIndex: 2,
        background: "var(--color-bg)",
      }}
    >
      <div
        style={{
          maxWidth: "1200px",
          margin: "0 auto",
          padding: "0 var(--space-md)",
        }}
      >
        {/* Top Row */}
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "var(--space-md)",
            marginBottom: "var(--space-lg)",
          }}
          className="md:!flex-row md:!justify-between md:!items-start"
        >
          {/* Brand Block */}
          <div>
            <p
              style={{
                fontFamily: "var(--font-display)",
                fontSize: "var(--text-lg)",
                color: "var(--color-text)",
                marginBottom: "2px",
              }}
            >
              TASTEANONYMOUS
            </p>
            <p
              style={{
                fontFamily: "var(--font-stamp)",
                fontSize: "var(--text-xs)",
                color: "var(--color-yellow)",
                letterSpacing: "0.1em",
                marginBottom: "var(--space-xs)",
              }}
            >
              THE SECRET CHEF
            </p>
            <p
              style={{
                fontFamily: "var(--font-body)",
                fontSize: "var(--text-sm)",
                color: "var(--color-text-muted)",
                lineHeight: 1.6,
              }}
            >
              Baton Rouge, LA · Open Daily 5:00 AM–1:00 AM
              <br />
              Call/Text:{" "}
              <a
                href="tel:+13376349915"
                style={{ color: "var(--color-text-muted)", textDecoration: "underline" }}
              >
                (337) 634-9915
              </a>
              {" "}· Private bookings via DM
              <br />
              <span
                style={{
                  fontFamily: "var(--font-stamp)",
                  fontSize: "var(--text-xs)",
                  color: "var(--color-red)",
                  fontStyle: "italic",
                }}
              >
                No online ordering. That's the point.
              </span>
            </p>
          </div>

          {/* Social Links */}
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: "var(--space-xs)",
            }}
            className="md:!items-end"
          >
            <a
              href="https://www.instagram.com/tasteanonymous"
              target="_blank"
              rel="noopener noreferrer"
              style={{
                fontFamily: "var(--font-stamp)",
                fontSize: "var(--text-sm)",
                color: "var(--color-text-muted)",
                textDecoration: "none",
                transition: "color 200ms ease",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.color = "var(--color-yellow)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.color = "var(--color-text-muted)";
              }}
            >
              Instagram
            </a>
            <a
              href="tel:+13376349915"
              style={{
                fontFamily: "var(--font-stamp)",
                fontSize: "var(--text-sm)",
                color: "var(--color-text-muted)",
                textDecoration: "none",
                transition: "color 200ms ease",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.color = "var(--color-yellow)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.color = "var(--color-text-muted)";
              }}
            >
              Call/Text
            </a>
          </div>
        </div>

        {/* Bottom Row — Copyright */}
        <div style={{ textAlign: "center" }}>
          <p
            style={{
              fontFamily: "var(--font-stamp)",
              fontSize: "var(--text-xs)",
              color: "var(--color-text-muted)",
              opacity: 0.6,
            }}
          >
            &copy; TasteAnonymous. The menu changes. The standard doesn't.
          </p>
        </div>
      </div>
    </footer>
  );
}
