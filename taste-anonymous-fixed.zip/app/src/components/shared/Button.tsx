import { useState, useCallback, type MouseEvent, type ReactNode } from "react";

interface ButtonProps {
  children: ReactNode;
  href?: string;
  onClick?: (e: MouseEvent) => void;
  variant?: "primary" | "danger";
  size?: "default" | "large";
  className?: string;
  type?: "button" | "submit";
}

export default function Button({
  children,
  href,
  onClick,
  variant = "primary",
  size = "default",
  className = "",
  type = "button",
}: ButtonProps) {
  const [isPressed, setIsPressed] = useState(false);
  const [flash, setFlash] = useState(false);

  const borderColor = variant === "danger" ? "var(--color-red)" : "var(--color-red)";
  const textColor = variant === "danger" ? "var(--color-red)" : "var(--color-yellow)";
  const glowColor = variant === "danger" ? "var(--color-red-glow)" : "var(--color-yellow-glow)";

  const handleClick = useCallback(
    (e: MouseEvent) => {
      setIsPressed(true);
      setFlash(true);

      setTimeout(() => setIsPressed(false), 200);
      setTimeout(() => setFlash(false), 500);

      onClick?.(e);
    },
    [onClick]
  );

  const baseStyles: React.CSSProperties = {
    position: "relative",
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    fontFamily: "var(--font-display)",
    fontSize: size === "large" ? "clamp(1.05rem, 4vw, var(--text-lg))" : "var(--text-base)",
    textTransform: "uppercase",
    letterSpacing: "0.05em",
    color: textColor,
    background: "var(--color-surface)",
    border: `1px solid ${borderColor}`,
    borderRadius: "var(--radius)",
    // Horizontal padding now scales with viewport instead of a fixed 110px (--space-2xl),
    // which was forcing large CTAs to wrap one word per line on phones.
    padding:
      size === "large"
        ? "var(--space-md) clamp(var(--space-md), 6vw, var(--space-2xl))"
        : "var(--space-sm) var(--space-xl)",
    textAlign: "center",
    cursor: "pointer",
    overflow: "hidden",
    transform: isPressed ? "scale(0.96)" : "scale(1)",
    transition: "transform 200ms cubic-bezier(0.34, 1.56, 0.64, 1)",
    textDecoration: "none",
  };

  const travelingGlowStyle: React.CSSProperties = {
    position: "absolute",
    inset: -2,
    borderRadius: "var(--radius)",
    padding: 2,
    background: `conic-gradient(from 0deg, transparent 0%, ${glowColor} 20%, transparent 40%, transparent 60%, ${glowColor} 80%, transparent 100%)`,
    backgroundSize: "200% 200%",
    WebkitMask: "linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",
    WebkitMaskComposite: "xor",
    maskComposite: "exclude",
    opacity: 0,
    transition: "opacity 300ms ease",
    pointerEvents: "none",
  };

  const flashStyle: React.CSSProperties = {
    position: "absolute",
    inset: 0,
    borderRadius: "var(--radius)",
    background: "radial-gradient(circle at center, rgba(232, 19, 46, 0.3) 0%, transparent 70%)",
    opacity: flash ? 1 : 0,
    transform: flash ? "scale(1.5)" : "scale(0.5)",
    transition: "opacity 300ms ease, transform 300ms ease",
    pointerEvents: "none",
  };

  const innerContent = (
    <>
      <span
        className="button-glow"
        style={travelingGlowStyle}
      />
      <span style={flashStyle} />
      <span style={{ position: "relative", zIndex: 2 }}>{children}</span>
    </>
  );

  if (href) {
    return (
      <a
        href={href}
        target={href.startsWith("http") ? "_blank" : undefined}
        rel={href.startsWith("http") ? "noopener noreferrer" : undefined}
        className={`group inline-block ${className}`}
        style={baseStyles}
        onClick={handleClick}
      >
        {innerContent}
      </a>
    );
  }

  return (
    <button
      type={type}
      className={`group ${className}`}
      style={baseStyles}
      onClick={handleClick}
    >
      {innerContent}
    </button>
  );
}
