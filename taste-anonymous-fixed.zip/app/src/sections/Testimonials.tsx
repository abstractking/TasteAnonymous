import ScrollReveal from "@/components/shared/ScrollReveal";
import { testimonials } from "@/data/testimonials";

export default function Testimonials() {
  return (
    <section
      style={{
        padding: "var(--space-2xl) 0",
        position: "relative",
        zIndex: 2,
        background: "var(--color-bg)",
      }}
    >
      <div
        style={{
          maxWidth: "1200px",
          margin: "0 auto",
          padding: "0 var(--space-md)",
        }}
      >
        {/* Section Label */}
        <ScrollReveal>
          <p
            style={{
              fontFamily: "var(--font-stamp)",
              fontSize: "var(--text-xs)",
              color: "var(--color-yellow)",
              letterSpacing: "0.25em",
              textTransform: "uppercase",
              marginBottom: "var(--space-lg)",
            }}
          >
            THE RECEIPTS
          </p>
        </ScrollReveal>

        {/* Asymmetric Layout */}
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "var(--space-xl)",
          }}
        >
          {/* Quote 1 — Wide, left */}
          <ScrollReveal delay={0}>
            <div
              className="md:!w-[55%]"
              style={{
                borderLeft: "3px solid var(--color-red)",
                paddingLeft: "var(--space-md)",
              }}
            >
              <p
                style={{
                  fontFamily: "var(--font-body)",
                  fontSize: "var(--text-xl)",
                  color: "var(--color-text)",
                  lineHeight: 1.4,
                  marginBottom: "var(--space-sm)",
                }}
              >
                "{testimonials[0].quote}"
              </p>
              <p
                style={{
                  fontFamily: "var(--font-stamp)",
                  fontSize: "var(--text-sm)",
                  color: "var(--color-text-muted)",
                }}
              >
                — {testimonials[0].author}, {testimonials[0].location}
              </p>
            </div>
          </ScrollReveal>

          {/* Quote 2 — Narrow, right, offset */}
          <ScrollReveal delay={0.15}>
            <div
              className="md:!w-[40%] md:!ml-auto"
              style={{
                borderLeft: "3px solid var(--color-yellow)",
                paddingLeft: "var(--space-md)",
                marginTop: undefined,
              }}
            >
              <p
                style={{
                  fontFamily: "var(--font-body)",
                  fontSize: "var(--text-lg)",
                  color: "var(--color-text)",
                  lineHeight: 1.4,
                  marginBottom: "var(--space-sm)",
                }}
              >
                "{testimonials[1].quote}"
              </p>
              <p
                style={{
                  fontFamily: "var(--font-stamp)",
                  fontSize: "var(--text-sm)",
                  color: "var(--color-text-muted)",
                }}
              >
                — {testimonials[1].author}, {testimonials[1].location}
              </p>
            </div>
          </ScrollReveal>

          {/* Quote 3 — Medium, left with indent */}
          <ScrollReveal delay={0.3}>
            <div
              className="md:!w-[50%] md:!ml-[var(--space-lg)]"
              style={{
                borderLeft: "3px solid var(--color-red)",
                paddingLeft: "var(--space-md)",
              }}
            >
              <p
                style={{
                  fontFamily: "var(--font-body)",
                  fontSize: "var(--text-xl)",
                  color: "var(--color-text)",
                  lineHeight: 1.4,
                  marginBottom: "var(--space-sm)",
                }}
              >
                "{testimonials[2].quote}"
              </p>
              <p
                style={{
                  fontFamily: "var(--font-stamp)",
                  fontSize: "var(--text-sm)",
                  color: "var(--color-text-muted)",
                }}
              >
                — {testimonials[2].author}, {testimonials[2].location}
              </p>
            </div>
          </ScrollReveal>
        </div>
      </div>
    </section>
  );
}
