export interface InstagramPost {
  dish: string;
  url: string;
  /** Evidence-tag caption shown under the embed, e.g. "DROPPED 06.14 — GONE BY SUNDAY" */
  caption: string;
  /** Shows a rotated red "RETIRED" stamp overlay on the card */
  retired?: boolean;
  /** Shows a diagonal hazard-tape corner ribbon — use sparingly, not on every card */
  ribbon?: boolean;
}

export const instagramPosts: InstagramPost[] = [
  {
    dish: "Hamburger & Potato Wedges",
    url: "https://www.instagram.com/reel/DZxqtdRiLDN/",
    caption: "DROPPED 06.14 — GONE BY MIDNIGHT",
    retired: true,
  },
  {
    dish: "Shrimp",
    url: "https://www.instagram.com/reel/DZvwhsDMrXH/",
    caption: "LAST SEEN SATURDAY",
    retired: true,
    ribbon: true,
  },
  {
    dish: "Steak",
    url: "https://www.instagram.com/reel/DZrG9x-NvOT/",
    caption: "ONE NIGHT ONLY — GONE",
    retired: true,
  },
  {
    dish: "Burger 2",
    url: "https://www.instagram.com/reel/DYNxggTPsTE/",
    caption: "DROPPED FRIDAY — SOLD OUT IN AN HOUR",
    retired: true,
    ribbon: true,
  },
  {
    dish: "Potato & Shrimp",
    // ⚠️ TODO: this currently points to the SAME url as "Burger 2" above.
    // Get the correct reel link from the client before launch.
    url: "https://www.instagram.com/reel/DYNxggTPsTE/",
    caption: "VAULTED — WON'T RETURN",
    retired: true,
  },
  {
    dish: "Chicken & Waffles",
    url: "https://www.instagram.com/reel/DWB1lFpjlX-/",
    caption: "RETIRED — DON'T ASK",
    retired: true,
    ribbon: true,
  },
  {
    dish: "Poboys",
    url: "https://www.instagram.com/p/DJ5UnSOP3wg/",
    caption: "DROPPED 06.10 — GONE BY SUNRISE",
    retired: true,
  },
  {
    dish: "Poboy 2",
    url: "https://www.instagram.com/p/DJ0IY_pv6sB/",
    caption: "STATUS: RETIRED",
    retired: true,
  },
];
