import { motion } from "framer-motion";
import EmberBackground from "@/components/shared/EmberBackground";
import Button from "@/components/shared/Button";
import { useCountdown } from "@/hooks/useCountdown";

export default function Hero() {
  const { days, hours, minutes, seconds, wasJustExpired } = useCountdown();

  const handleClaimClick = () => {
    const el = document.querySelector("#contact");
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      id="hero"
      style={{
        position: "relative",
        width: "100%",
        minHeight: "600px",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        overflow: "hidden",
        background: "var(--color-bg)",
      }}
    >
      {/* Ember Particles */}
      <EmberBackground density="full" />

      {/* Breathing Glow */}
      <div
        className="breathe-glow"
        style={{
          position: "absolute",
          inset: 0,
          background:
            "radial-gradient(circle at 50% 50%, rgba(232,19,46,0.15), rgba(244,213,0,0.08), transparent 70%)",
          animation: "breatheGlow var(--duration-ambient) var(--ease-smooth) infinite",
          zIndex: 0,
          pointerEvents: "none",
        }}
      />

      {/* Content */}
      <div
        style={{
          position: "relative",
          zIndex: 1,
          maxWidth: "800px",
          padding: "0 var(--space-md)",
          textAlign: "center",
        }}
      >
        {/* Eyebrow */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3, ease: [0.4, 0, 0.2, 1] }}
          style={{
            fontFamily: "var(--font-stamp)",
            fontSize: "var(--text-sm)",
            textTransform: "uppercase",
            letterSpacing: "0.25em",
            color: "var(--color-yellow)",
            marginBottom: "var(--space-sm)",
          }}
        >
          THE SECRET CHEF
        </motion.p>

        {/* Headline */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5, ease: [0.4, 0, 0.2, 1] }}
          style={{
            fontFamily: "var(--font-display)",
            fontSize: "clamp(2.2rem, 7vw, 5.5rem)",
            color: "var(--color-text)",
            textTransform: "uppercase",
            letterSpacing: "0.02em",
            lineHeight: 1.0,
            marginBottom: "var(--space-md)",
          }}
        >
          THE MENU YOU DON'T SEE TWICE.
        </motion.h1>

        {/* Subheadline */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.7, ease: [0.4, 0, 0.2, 1] }}
          style={{
            fontFamily: "var(--font-body)",
            fontSize: "var(--text-lg)",
            color: "var(--color-text-muted)",
            maxWidth: "560px",
            margin: "0 auto var(--space-xl)",
            lineHeight: 1.5,
          }}
        >
          Premium, heavily-seasoned comfort food. Baton Rouge's most wanted plate.
        </motion.p>

        {/* Countdown Timer */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.9, ease: [0.4, 0, 0.2, 1] }}
          style={{ marginBottom: "var(--space-lg)" }}
        >
          <p
            style={{
              fontFamily: "var(--font-stamp)",
              fontSize: "var(--text-xs)",
              color: "var(--color-red)",
              textTransform: "uppercase",
              letterSpacing: "0.2em",
              marginBottom: "var(--space-sm)",
            }}
          >
            {wasJustExpired ? "VAULT CLOSED" : "VAULT CLOSES IN"}
          </p>

          <div
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "var(--space-sm)",
              border: "1px dashed var(--color-border)",
              padding: "var(--space-md)",
            }}
          >
            {[
              { value: days, label: "D" },
              { value: hours, label: "H" },
              { value: minutes, label: "M" },
              { value: seconds, label: "S" },
            ].map((item, i) => (
              <div key={item.label} style={{ display: "flex", alignItems: "center", gap: "var(--space-xs)" }}>
                <div style={{ textAlign: "center" }}>
                  <span
                    style={{
                      fontFamily: "var(--font-display)",
                      fontSize: "var(--text-2xl)",
                      color: "var(--color-yellow)",
                      lineHeight: 1,
                    }}
                  >
                    {String(item.value).padStart(2, "0")}
                  </span>
                  <span
                    style={{
                      display: "block",
                      fontFamily: "var(--font-stamp)",
                      fontSize: "var(--text-xs)",
                      color: "var(--color-text-muted)",
                      letterSpacing: "0.1em",
                    }}
                  >
                    {item.label}
                  </span>
                </div>
                {i < 3 && (
                  <span
                    className="blink"
                    style={{
                      fontFamily: "var(--font-display)",
                      fontSize: "var(--text-xl)",
                      color: "var(--color-yellow)",
                      lineHeight: 1,
                    }}
                  >
                    :
                  </span>
                )}
              </div>
            ))}
          </div>

          <p
            style={{
              fontFamily: "var(--font-stamp)",
              fontSize: "var(--text-xs)",
              color: "var(--color-text-muted)",
              marginTop: "var(--space-sm)",
            }}
          >
            Resets every Sunday at midnight
          </p>
        </motion.div>

        {/* CTA Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.1, ease: [0.4, 0, 0.2, 1] }}
        >
          <Button onClick={handleClaimClick} size="large">
            CLAIM THIS WEEK'S DROP
          </Button>
        </motion.div>

        {/* Microcopy */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.3, ease: [0.4, 0, 0.2, 1] }}
          style={{
            fontFamily: "var(--font-body)",
            fontSize: "var(--text-sm)",
            color: "var(--color-text-muted)",
            maxWidth: "420px",
            margin: "var(--space-md) auto 0",
            lineHeight: 1.5,
          }}
        >
          New drop every week, straight to Stories. Pickup & delivery only — no dine-in, no distractions.
        </motion.p>

        {/* Tagline */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.5, ease: [0.4, 0, 0.2, 1] }}
          style={{
            fontFamily: "var(--font-stamp)",
            fontSize: "var(--text-xs)",
            fontStyle: "italic",
            color: "var(--color-red)",
            opacity: 0.7,
            marginTop: "var(--space-sm)",
          }}
        >
          What's hot this week is gone by Sunday.
        </motion.p>
      </div>
    </section>
  );
}
