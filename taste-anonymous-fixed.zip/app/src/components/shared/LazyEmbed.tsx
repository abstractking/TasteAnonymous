import type { ReactNode } from "react";
import { useIntersectionObserver } from "@/hooks/useIntersectionObserver";

interface LazyEmbedProps {
  children: ReactNode;
}

export default function LazyEmbed({ children }: LazyEmbedProps) {
  const [ref, isVisible] = useIntersectionObserver({
    threshold: 0,
    rootMargin: "200px",
    freezeOnceVisible: true,
  });

  return (
    <div ref={ref} className="w-full h-full min-h-[400px]">
      {isVisible ? (
        children
      ) : (
        <div
          className="w-full h-[400px] flex items-center justify-center"
          style={{
            background: "var(--color-bg-2)",
            border: "1px solid var(--color-yellow)",
            borderRadius: "var(--radius)",
          }}
        >
          <span
            className="font-stamp"
            style={{
              fontSize: "var(--text-xs)",
              color: "var(--color-text-muted)",
              letterSpacing: "0.15em",
            }}
          >
            LOADING EVIDENCE...
          </span>
        </div>
      )}
    </div>
  );
}
