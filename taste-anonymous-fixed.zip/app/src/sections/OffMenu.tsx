import ScrollReveal from "@/components/shared/ScrollReveal";
import Button from "@/components/shared/Button";

export default function OffMenu() {
  return (
    <section
      style={{
        padding: "var(--space-2xl) 0",
        position: "relative",
        zIndex: 2,
        background: "var(--color-bg)",
      }}
    >
      <div
        style={{
          maxWidth: "1200px",
          margin: "0 auto",
          padding: "0 var(--space-md)",
        }}
      >
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "var(--space-lg)",
          }}
          className="md:!flex-row md:!items-center"
        >
          {/* Text Block (60%) */}
          <ScrollReveal direction="left" className="md:!w-[60%]">
            <h2
              style={{
                fontFamily: "var(--font-display)",
                fontSize: "var(--text-2xl)",
                color: "var(--color-text)",
                textTransform: "uppercase",
                lineHeight: 1.1,
                marginBottom: "var(--space-sm)",
              }}
            >
              WANT HIM IN YOUR KITCHEN INSTEAD?
            </h2>
            <p
              style={{
                fontFamily: "var(--font-body)",
                fontSize: "var(--text-base)",
                color: "var(--color-text-muted)",
                lineHeight: 1.6,
                maxWidth: "480px",
              }}
            >
              Private dinners, pop-ups, and events — booked direct, by request only. No packages, no price list. DM and explain what you need.
            </p>
          </ScrollReveal>

          {/* CTA Button (40%) */}
          <ScrollReveal delay={0.15} className="md:!w-[40%] md:!flex md:!justify-end">
            <Button
              href="https://www.instagram.com/tasteanonymous"
              variant="danger"
            >
              DM TO BOOK PRIVATE SERVICES
            </Button>
          </ScrollReveal>
        </div>
      </div>
    </section>
  );
}
