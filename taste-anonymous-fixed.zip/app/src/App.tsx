import Navbar from "@/sections/Navbar";
import Hero from "@/sections/Hero";
import SignatureDrops from "@/sections/SignatureDrops";
import About from "@/sections/About";
import Lineup from "@/sections/Lineup";
import Testimonials from "@/sections/Testimonials";
import CTASection from "@/sections/CTASection";
import OffMenu from "@/sections/OffMenu";
import Footer from "@/sections/Footer";

export default function App() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <SignatureDrops />
        <About />
        <Lineup />
        <Testimonials />
        <CTASection />
        <OffMenu />
      </main>
      <Footer />
    </>
  );
}
