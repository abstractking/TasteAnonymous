import ScrollReveal from "@/components/shared/ScrollReveal";

export default function About() {
  return (
    <section
      id="about"
      style={{
        padding: "var(--space-3xl) 0",
        position: "relative",
        zIndex: 2,
        background: "var(--color-bg)",
      }}
    >
      <div
        style={{
          maxWidth: "1200px",
          margin: "0 auto",
          padding: "0 var(--space-md)",
        }}
      >
        <div style={{ maxWidth: "800px" }}>
          <ScrollReveal direction="left">
            <h2
              style={{
                fontFamily: "var(--font-display)",
                fontSize: "clamp(2rem, 5vw, 4.2rem)",
                color: "var(--color-text)",
                textTransform: "uppercase",
                lineHeight: 1.05,
                marginBottom: "var(--space-lg)",
              }}
            >
              NO FACE. NO FRANCHISE. NO REPEATS.
            </h2>
          </ScrollReveal>

          <ScrollReveal delay={0.2}>
            <p
              style={{
                fontFamily: "var(--font-body)",
                fontSize: "var(--text-lg)",
                color: "var(--color-text-muted)",
                lineHeight: 1.6,
              }}
            >
              This isn't a restaurant — it's a rotation. Every plate gets one week in the spotlight, then it's gone for good. We don't cook for comfort. We cook for the people who show up ready, on time, and hungry for something that won't be here next week. If that's not you, there's a drive-thru three minutes up the road.
            </p>
          </ScrollReveal>
        </div>
      </div>
    </section>
  );
}
