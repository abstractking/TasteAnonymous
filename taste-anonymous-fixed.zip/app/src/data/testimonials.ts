export interface Testimonial {
  id: string;
  quote: string;
  author: string;
  location: string;
  accentColor: "red" | "yellow";
}

export const testimonials: Testimonial[] = [
  {
    id: "deja",
    quote: "Texted at 11:40PM not expecting a reply. Had the Spud in my hand by midnight. Don't ask questions, just call.",
    author: "Deja R.",
    location: "Baton Rouge",
    accentColor: "red",
  },
  {
    id: "marcus",
    quote: "I missed the Trackers drop one Friday and I'm still not over it. Set a reminder now.",
    author: "Marcus T.",
    location: "LSU",
    accentColor: "yellow",
  },
  {
    id: "priya",
    quote: "This man runs a burger like it's a sneaker release. I respect it.",
    author: "Priya N.",
    location: "Local",
    accentColor: "red",
  },
];
