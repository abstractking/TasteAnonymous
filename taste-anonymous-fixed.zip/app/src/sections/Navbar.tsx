import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

const navLinks = [
  { label: "HOME", href: "#" },
  { label: "THE VAULT", href: "#the-vault" },
  { label: "THE LINEUP", href: "#the-lineup" },
  { label: "ABOUT", href: "#about" },
  { label: "CONTACT", href: "#contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 80);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMenuOpen(false);
    if (href === "#") {
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else {
      const el = document.querySelector(href);
      if (el) {
        el.scrollIntoView({ behavior: "smooth" });
      }
    }
  };

  return (
    <nav
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100,
        height: "64px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "0 var(--space-md)",
        // Previously fully "transparent" pre-scroll, which let the Hero's eyebrow/headline
        // (which has no top offset for this fixed bar) render directly behind the logo text,
        // causing visible overlap. A permanent soft scrim keeps the floating look but stays legible.
        background: scrolled
          ? "var(--color-bg-2)"
          : "linear-gradient(to bottom, rgba(10,10,10,0.7) 0%, rgba(10,10,10,0.25) 100%)",
        borderBottom: scrolled ? "1px solid var(--color-border)" : "1px solid transparent",
        backdropFilter: scrolled ? "blur(8px)" : "blur(2px)",
        WebkitBackdropFilter: scrolled ? "blur(8px)" : "blur(2px)",
        transition: "background 300ms ease, border-color 300ms ease, backdrop-filter 300ms ease",
      }}
    >
      {/* Logo Lockup */}
      <a href="#" onClick={(e) => handleNavClick(e, "#")} style={{ textDecoration: "none" }}>
        <div style={{ display: "flex", flexDirection: "column" }}>
          <span
            style={{
              fontFamily: "var(--font-display)",
              fontSize: "1.2rem",
              color: "var(--color-text)",
              letterSpacing: "0.08em",
              lineHeight: 1.1,
            }}
          >
            TASTEANONYMOUS
          </span>
          <span
            style={{
              fontFamily: "var(--font-stamp)",
              fontSize: "var(--text-xs)",
              color: "var(--color-text-muted)",
              letterSpacing: "0.15em",
            }}
          >
            THE SECRET CHEF
          </span>
        </div>
      </a>

      {/* Desktop Nav Links */}
      <div
        className="hidden md:flex"
        style={{ alignItems: "center", gap: "var(--space-md)" }}
      >
        {navLinks.map((link) => (
          <a
            key={link.label}
            href={link.href}
            onClick={(e) => handleNavClick(e, link.href)}
            className="nav-link"
            style={{
              fontFamily: "var(--font-body)",
              fontSize: "var(--text-sm)",
              textTransform: "uppercase",
              letterSpacing: "0.08em",
              color: "var(--color-text)",
              opacity: 0.8,
              textDecoration: "none",
              transition: "opacity 200ms ease, color 200ms ease",
              position: "relative",
              paddingBottom: "2px",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.opacity = "1";
              e.currentTarget.style.color = "var(--color-yellow)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.opacity = "0.8";
              e.currentTarget.style.color = "var(--color-text)";
            }}
          >
            {link.label}
          </a>
        ))}

        {/* Click-to-Call */}
        <a
          href="tel:+13376349915"
          className="hidden lg:inline-flex"
          style={{
            fontFamily: "var(--font-stamp)",
            fontSize: "var(--text-sm)",
            color: "var(--color-yellow)",
            border: "1px solid var(--color-red)",
            padding: "var(--space-xs) var(--space-sm)",
            background: "transparent",
            textDecoration: "none",
            transition: "background 200ms ease, color 200ms ease",
            marginLeft: "var(--space-sm)",
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = "var(--color-red)";
            e.currentTarget.style.color = "var(--color-bg)";
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = "transparent";
            e.currentTarget.style.color = "var(--color-yellow)";
          }}
        >
          (337) 634-9915
        </a>
      </div>

      {/* Hamburger (mobile) */}
      <button
        className="md:hidden"
        onClick={() => setMenuOpen(!menuOpen)}
        style={{
          background: "none",
          border: "none",
          cursor: "pointer",
          padding: "var(--space-xs)",
          display: "flex",
          flexDirection: "column",
          gap: "6px",
        }}
        aria-label="Toggle menu"
      >
        {menuOpen ? (
          <span
            style={{
              fontSize: "2rem",
              color: "var(--color-text)",
              lineHeight: 1,
            }}
          >
            &times;
          </span>
        ) : (
          <>
            <span
              style={{
                display: "block",
                width: "24px",
                height: "2px",
                background: "var(--color-text)",
                transition: "transform 200ms ease",
              }}
            />
            <span
              style={{
                display: "block",
                width: "24px",
                height: "2px",
                background: "var(--color-text)",
                transition: "transform 200ms ease",
              }}
            />
          </>
        )}
      </button>

      {/* Mobile Menu Panel */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] }}
            style={{
              position: "absolute",
              top: "64px",
              left: 0,
              right: 0,
              background: "var(--color-bg-2)",
              overflow: "hidden",
              zIndex: 99,
            }}
          >
            <div
              style={{
                padding: "var(--space-lg) var(--space-md)",
                display: "flex",
                flexDirection: "column",
                gap: "var(--space-md)",
              }}
            >
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  style={{
                    fontFamily: "var(--font-body)",
                    fontSize: "var(--text-lg)",
                    color: "var(--color-text)",
                    textDecoration: "none",
                    transition: "color 200ms ease",
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.color = "var(--color-yellow)";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.color = "var(--color-text)";
                  }}
                >
                  {link.label}
                </a>
              ))}
              <a
                href="tel:+13376349915"
                style={{
                  fontFamily: "var(--font-stamp)",
                  fontSize: "var(--text-base)",
                  color: "var(--color-yellow)",
                  border: "1px solid var(--color-red)",
                  padding: "var(--space-sm) var(--space-md)",
                  textAlign: "center",
                  textDecoration: "none",
                  marginTop: "var(--space-sm)",
                }}
              >
                (337) 634-9915
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
