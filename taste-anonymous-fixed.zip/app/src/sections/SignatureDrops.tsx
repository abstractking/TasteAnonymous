import { motion } from "framer-motion";
import ScrollReveal from "@/components/shared/ScrollReveal";
import { dishes } from "@/data/dishes";

export default function SignatureDrops() {
  return (
    <section
      id="the-vault"
      style={{
        padding: "var(--space-3xl) 0",
        position: "relative",
        zIndex: 2,
        background: "var(--color-bg)",
      }}
    >
      <div
        style={{
          maxWidth: "1200px",
          margin: "0 auto",
          padding: "0 var(--space-md)",
        }}
      >
        {/* Section Label */}
        <ScrollReveal>
          <p
            style={{
              fontFamily: "var(--font-stamp)",
              fontSize: "var(--text-xs)",
              color: "var(--color-yellow)",
              letterSpacing: "0.25em",
              textTransform: "uppercase",
              marginBottom: "var(--space-sm)",
            }}
          >
            THE VAULT
          </p>
        </ScrollReveal>

        {/* Section Headline */}
        <ScrollReveal delay={0.1}>
          <h2
            style={{
              fontFamily: "var(--font-display)",
              fontSize: "var(--text-2xl)",
              color: "var(--color-text)",
              textTransform: "uppercase",
              marginBottom: "var(--space-xl)",
              lineHeight: 1.1,
            }}
          >
            WHAT'S AVAILABLE THIS WEEK
          </h2>
        </ScrollReveal>

        {/* Asymmetric Grid */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(1, 1fr)",
            gap: "var(--space-md)",
          }}
          className="md:!grid-cols-2"
        >
          {dishes.map((dish, index) => {
            const isLarge = dish.size === "large";
            const isSmall = dish.size === "small";

            return (
              <ScrollReveal
                key={dish.id}
                delay={0.15 * index}
                className={isLarge ? "md:row-span-2" : ""}
              >
                <motion.div
                  whileHover={{ rotate: -1, scale: 1.02 }}
                  transition={{ duration: 0.2, ease: [0.34, 1.56, 0.64, 1] }}
                  style={{
                    position: "relative",
                    background: "var(--color-bg-2)",
                    border: dish.isWildcard
                      ? "1px dashed var(--color-border)"
                      : "1px solid var(--color-yellow)",
                    borderRadius: "var(--radius)",
                    padding: "var(--space-lg)",
                    height: isLarge ? "100%" : "auto",
                    minHeight: isLarge ? "400px" : isSmall ? "180px" : "280px",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: isLarge ? "center" : "flex-start",
                    cursor: "default",
                  }}
                >
                  {/* Hazard Ribbon */}
                  {dish.hasHazardRibbon && (
                    <div
                      style={{
                        position: "absolute",
                        top: 0,
                        right: 0,
                        width: "60px",
                        height: "60px",
                        overflow: "hidden",
                      }}
                    >
                      <div
                        style={{
                          position: "absolute",
                          top: "8px",
                          right: "-18px",
                          width: "80px",
                          height: "20px",
                          background: "repeating-linear-gradient(45deg, var(--color-red), var(--color-red) 4px, transparent 4px, transparent 8px)",
                          transform: "rotate(45deg)",
                        }}
                      />
                    </div>
                  )}

                  {/* Card Content */}
                  <h3
                    style={{
                      fontFamily: "var(--font-display)",
                      fontSize: isLarge
                        ? "var(--text-2xl)"
                        : isSmall
                        ? "var(--text-lg)"
                        : "var(--text-xl)",
                      color: "var(--color-text)",
                      textTransform: "uppercase",
                      lineHeight: 1.1,
                      marginBottom: "var(--space-sm)",
                    }}
                  >
                    {dish.name}
                  </h3>

                  <p
                    style={{
                      fontFamily: "var(--font-body)",
                      fontSize: "var(--text-base)",
                      color: "var(--color-text-muted)",
                      lineHeight: 1.5,
                      marginBottom: "var(--space-md)",
                      maxWidth: "400px",
                    }}
                  >
                    {dish.description}
                  </p>

                  {/* Evidence Tag */}
                  <div style={{ marginTop: "auto" }}>
                    <span
                      style={{
                        fontFamily: "var(--font-stamp)",
                        fontSize: "var(--text-xs)",
                        color:
                          dish.tagColor === "red"
                            ? "var(--color-red)"
                            : "var(--color-yellow)",
                        letterSpacing: "0.1em",
                      }}
                    >
                      {dish.tag}
                    </span>
                  </div>
                </motion.div>
              </ScrollReveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
